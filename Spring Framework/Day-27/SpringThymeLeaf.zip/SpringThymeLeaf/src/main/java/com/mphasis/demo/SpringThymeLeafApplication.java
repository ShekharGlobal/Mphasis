package com.mphasis.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScans;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@ComponentScans({@ComponentScan("com.mphasis.controller"),
	@ComponentScan("com.mphasis.service")})
@EntityScan("com.mphasis.entity")
@EnableJpaRepositories("com.mphasis.repository")
public class SpringThymeLeafApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringThymeLeafApplication.class, args);
	}

}
