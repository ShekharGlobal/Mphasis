package com.mphasis.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mphasis.entity.Product;
import com.mphasis.service.ProductService;

@Controller
@RequestMapping("/products")
public class ProductController {

    @Autowired
    private ProductService productService;

    // Thymeleaf View Endpoints

    @GetMapping
    public String viewHomePage(Model model) {
        List<Product> products = productService.getAllProducts();
        model.addAttribute("listProducts", products);
        return "index";
    }


    @GetMapping("/showNewProductForm")
    public String showNewProductForm(Model model) {
        Product product = new Product();
        model.addAttribute("product", product);
        return "new_product";  // This should match the name of your Thymeleaf template
    }

    @PostMapping("/saveProduct")
    public String saveProduct(@ModelAttribute("product") Product product) {
        productService.saveProduct(product);
        return "redirect:/products";  // Redirect to the list of products after saving
    }

    @GetMapping("/showFormForUpdate/{id}")
    public String showFormForUpdate(@PathVariable(value = "id") long id, Model model) {
        Optional<Product> product = productService.getProductById(id);
        if (product.isPresent()) {
            model.addAttribute("product", product.get());
            return "update_product";  // Thymeleaf template for updating a product
        } else {
            return "redirect:/products";  // Redirect if product not found
        }
    }

    @PostMapping("/updateProduct/{id}")
    public String updateProduct(@PathVariable(value = "id") long id, @ModelAttribute("product") Product product) {
        product.setId(id);
        productService.saveProduct(product);
        return "redirect:/products";  // Redirect to the list of products after updating
    }

    @GetMapping("/deleteProduct/{id}")
    public String deleteProduct(@PathVariable(value = "id") long id) {
        productService.deleteProduct(id);
        return "redirect:/products";  // Redirect to the list of products after deletion
    }
}
