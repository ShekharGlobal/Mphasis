package com.example.secondlevels;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class SecondLevelCacheDemo {

    public static void main(String[] args) {

        SessionFactory factory = new Configuration()
                .configure("hibernate.cfg.xml")
                .addAnnotatedClass(Student.class)
                .buildSessionFactory();

        try {

            // ---------- INSERT RECORD ONLY IF NOT EXISTS ----------
            Session insertSession = factory.openSession();
            Transaction tx0 = insertSession.beginTransaction();

            Student existing = insertSession.get(Student.class, 1);
            if (existing == null) {
                Student s = new Student(1, "Venkat");
                insertSession.save(s);
                System.out.println("Inserted Student: " + s);
            } else {
                System.out.println("Student already exists: " + existing);
            }

            tx0.commit();
            insertSession.close();


            // ---------- SESSION 1 (DB HIT) ----------
            Session s1 = factory.openSession();
            Transaction tx1 = s1.beginTransaction();

            System.out.println("\nSESSION 1 → DB HIT expected:");
            Student st1 = s1.get(Student.class, 1);  // SQL SELECT will run
            System.out.println("Session 1 fetched: " + st1);

            tx1.commit();
            s1.close();


            // ---------- SESSION 2 (NO DB HIT → L2 CACHE) ----------
            Session s2 = factory.openSession();
            Transaction tx2 = s2.beginTransaction();

            System.out.println("\nSESSION 2 → NO DB HIT (L2 Cache) expected:");
            Student st2 = s2.get(Student.class, 1);  // NO SQL → from L2 Cache
            System.out.println("Session 2 fetched: " + st2);

            tx2.commit();
            s2.close();


        } finally {
            factory.close();
        }
    }
}
