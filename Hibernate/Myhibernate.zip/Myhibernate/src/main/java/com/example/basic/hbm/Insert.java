package com.example.basic.hbm;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;



public class Insert {

	public static void main(String[] args) {
		
	   Configuration cfg = new Configuration().configure("hibernate.cfg.xml");
	   SessionFactory factory =cfg.buildSessionFactory();
	   Session session =factory.openSession();
	   Transaction transaction= session.beginTransaction();
	   
	   Employee emp= new Employee();
	   emp.setId(103);
	   emp.setFirstName("Venkat");
	   emp.setLastName("R");
	   
	   session.save(emp);// persistant object
	   transaction.commit();
	   factory.close();
	   session.close();
	   
	   
	   
	   
	   

	}

}
