package com.example.uni.onetomany;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Main {

    public static void main(String[] args) {
        Configuration cfg = new Configuration().configure("hibernate.cfg.xml");
        SessionFactory sessionFactory = cfg.buildSessionFactory();

        // Creating a department
        Department department = new Department();
        department.setName("HR");

        // Adding employees to the department
        Employee emp1 = new Employee();
        emp1.setFirstName("Venkat");
        emp1.setLastName("S");

        Employee emp2 = new Employee();
        emp2.setFirstName("Krishna");
        emp2.setLastName("S");

        department.addEmployee(emp1);
        department.addEmployee(emp2);

        // Saving the department (employees will be saved automatically due to CascadeType.ALL)
        try (Session session = sessionFactory.openSession()) {
            Transaction transaction = session.beginTransaction();
            session.save(department);
            transaction.commit();
        }

		/*
		 * // Retrieving the department and its employees try (Session session =
		 * sessionFactory.openSession()) { Department retrievedDepartment =
		 * session.get(Department.class, 1);
		 * 
		 * System.out.println("Department: " + retrievedDepartment.getName()); for
		 * (Employee employee : retrievedDepartment.getEmployees()) {
		 * System.out.println("Employee: " + employee.getFirstName() + " " +
		 * employee.getLastName()); } }
		 */

        sessionFactory.close();
    }
}
