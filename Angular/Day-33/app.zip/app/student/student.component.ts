import { Component, inject } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService } from '../api.service';

@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css']
})
export class StudentComponent {
  router = inject(Router);
  appService = inject(ApiService)
  studentName: string = '';
  courses: { name: string }[] = [{ name: '' }, { name: '' }];

  register(form: NgForm) {
    // Check if student name or any course name is blank
    if (!this.studentName.trim() || this.courses.some(course => !course.name.trim())) {
      console.log('Student name or course name cannot be blank');
      return;
    }

    const payload = {
      "student": {
        "name": this.studentName
      },
      "courses": this.courses
    };

    this.appService.createStudentAndCourses(payload).subscribe(
      response => {
        console.log('Student and courses created successfully:', response);
        // Redirect to the view page
        this.router.navigateByUrl("course")
      },
      error => {
        console.error('Failed to create student and courses:', error);
      }
    );
  }
}
