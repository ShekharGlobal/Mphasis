package com.example.dao;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/RegistrationServlet")
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        User user = new User();
        
        user.setUsername(username);
        user.setPassword(password);

        UserDao userDAO = new UserDao();
        //the setter value passed to the RegisterUser
        int rowsAffected = userDAO.registerUser(user);

        
        
        
        if (rowsAffected > 0) {
            response.getWriter().println("Registration successful!");
        } else {
            response.getWriter().println("Registration failed!");
        }

}
}
