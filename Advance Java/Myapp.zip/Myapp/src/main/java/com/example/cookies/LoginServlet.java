package com.example.cookies;

import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/LoginServlettt")
public class LoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String location = request.getParameter("location");

        if ("admin".equals(username) && "admin".equals(password)) {
            String encodedUsername = URLEncoder.encode(username, StandardCharsets.UTF_8.toString());
            String encodedLocation = URLEncoder.encode(location, StandardCharsets.UTF_8.toString());

            Cookie userCookie = new Cookie("user", encodedUsername);
            Cookie locationCookie = new Cookie("location", encodedLocation);
            
            response.addCookie(userCookie);
            response.addCookie(locationCookie);
            
            response.sendRedirect("Inboxx");
        } else {
            response.sendRedirect("cookies.html");
        }
    }
}
