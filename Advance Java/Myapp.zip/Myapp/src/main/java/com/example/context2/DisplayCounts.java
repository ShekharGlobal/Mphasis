package com.example.context2;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/DisplayCounts")
public class DisplayCounts extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ServletContext context;

	public void init(ServletConfig config) throws ServletException {
		super.init(config); // Ensure parent class init is called
		context = config.getServletContext();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");

		String count = context.getAttribute("count").toString();

		out.print("<html><head><title>Display Count</title></head>");
		out.print("<body>");
		out.print("<h1>The Site was visited " + count + " times</h1>");
		out.print("</body></html>");

		//context.removeAttribute("count");
	}
}
