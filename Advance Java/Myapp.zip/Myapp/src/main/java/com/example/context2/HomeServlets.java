package com.example.context2;

import java.io.IOException;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/HomeServlets")
public class HomeServlets extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private ServletContext context;
    private String initCount;

    public void init(ServletConfig config) throws ServletException {
        super.init(config); // Ensure parent class init is called
        context = config.getServletContext();  
        System.out.println(context);
        initCount = context.getInitParameter("initialCount");
        System.out.println(initCount);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String countValue;
        
        if (context.getAttribute("count") != null) {
            countValue = context.getAttribute("count").toString();
        } else {
            countValue = initCount;
        }
        
        int count = Integer.parseInt(countValue);
        count++;
        context.setAttribute("count", count);
		
		/*
		 * response.setContentType("text/html");
		 * response.getWriter().println("<html><body>");
		 * response.getWriter().println("<h1>Welcome! Site visit count updated to " +
		 * count + "</h1>"); response.getWriter().println("</body></html>");
		 */
		 
    }
}
