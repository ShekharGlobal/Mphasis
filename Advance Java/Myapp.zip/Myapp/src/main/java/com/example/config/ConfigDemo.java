package com.example.config;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebInitParam;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(value = "/ConfigDemo", initParams = { 
		            @WebInitParam(name = "adminEmail1", value = "admin@example.com") 
		            }
             )
public class ConfigDemo extends HttpServlet {
	private String adminEmail;

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		   adminEmail = config.getInitParameter("adminEmail1");
		      if (adminEmail == null) { // fallback to context-param
			      adminEmail = getServletContext().getInitParameter("adminEmail");
		}
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		try (PrintWriter out = response.getWriter()) {
			out.println("<html><head><title>Config Demo</title></head><body>");
			out.println("<h1>The Admin Email is: " + adminEmail + "</h1>");
			out.println("</body></html>");
		}
	}
}
