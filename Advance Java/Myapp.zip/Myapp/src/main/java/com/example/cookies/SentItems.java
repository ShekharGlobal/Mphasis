package com.example.cookies;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/SentItemss")
public class SentItems extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Cookie[] cookies = request.getCookies();
        String userName = null;
        String location = null;

        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if ("user".equals(cookie.getName())) {
                    userName = URLDecoder.decode(cookie.getValue(), StandardCharsets.UTF_8.toString());
                } else if ("location".equals(cookie.getName())) {
                    location = URLDecoder.decode(cookie.getValue(), StandardCharsets.UTF_8.toString());
                }
            }
        }

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.print("<html><head><title>Sent Items</title></head><body>");
        out.print("<h1 style=\"margin-left:40px;\">Sent Items Page</h1>");
        if (userName != null && location != null) {
            out.print("<h2>Welcome " + userName + "</h2>");
            out.print("<h2>Location " + location + "</h2>");
        } else {
            out.print("<h2>Missing user or location information.</h2>");
        }
        out.print("<a href='" + request.getContextPath() + "/Inboxx'>Inbox</a>");
        out.print("</body></html>");
    }
}
