<%@ page language="java" contentType="text/html; charset=ISO-8859-1" 
         pageEncoding="ISO-8859-1" %>

<%@ taglib uri="/WEB-INF/tags.tld" prefix="st" %>

<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
    <title>Custom Tag Demo</title>
</head>
<body>
    <h2>Current Time:</h2>

    <!-- Custom tag usage -->
    <st:Date />
</body>
</html>
