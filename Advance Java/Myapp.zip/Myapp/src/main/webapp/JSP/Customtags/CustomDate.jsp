<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
         pageEncoding="ISO-8859-1" %>

<%@ taglib uri="/WEB-INF/date.tld" prefix="st" %>

<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
    <title>CustomTagDemo</title>
</head>

<body>
    <h2>Current Date:</h2>

    <st:Date />

</body>
</html>
