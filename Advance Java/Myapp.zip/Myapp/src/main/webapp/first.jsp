<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	<%
	int x = 1000;
	int y = 3000;
	int sum = x + y;
	out.println(sum);
	%>
	
	<%="Welcome" %>


</body>
</html>